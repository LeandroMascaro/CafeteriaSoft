/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.painel;

import br.com.unicamp.ft.CafeteriaSoft.entidade.EntityAbstract;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author leandro
 */
public class DefaultSeachTableModel extends DefaultTableModel{
    private List<EntityAbstract> entityAbstract;
    
    public DefaultSeachTableModel(List<EntityAbstract> entityAbstract){
        if(!entityAbstract.isEmpty()){
            this.entityAbstract = entityAbstract;
            setDataVector(EntityAbstract.toMatrixObject(entityAbstract),this.entityAbstract.get(0).getOwnAtrributes());
        }
    }
}
