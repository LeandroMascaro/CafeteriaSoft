/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.painel;

import br.com.unicamp.ft.CafeteriaSoft.entidade.EntityAbstract;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.JComboBox;

/**
 *
 * @author leandro
 */
public class JComboBoxEntityAbstract<T extends EntityAbstract>{
    
    private List<T> listItems = new ArrayList<T>();
    private JComboBox<String> cb;
    
    public JComboBoxEntityAbstract(List<T> items, JComboBox<String> cb){
        super();
        cb.removeAllItems();
        this.cb = cb;
        add(items);
    }

    public void add(List<T> items){
        items.forEach(item -> add(item));
    }
    
    public void add(T item){        
        if(!listItems.contains(item)){
            this.listItems.add(item);
            this.cb.addItem(String.valueOf(item.getId()) 
                 + JFrameMain.CHARACTER_SPLIT_CONTENT_SELECT_CB
                 + item.getIdentifier());        
        }        
    }
    
    public String getIdSelectIndex(int selectIndex){
        String strSelect = cb.getItemAt(selectIndex);
        String[] splitStrSelect = strSelect.split(JFrameMain.CHARACTER_SPLIT_CONTENT_SELECT_CB);
        return splitStrSelect[0];
    }
    
    public T getObject(int selectIndex){
        T objectReturn = null;
        String strId = getIdSelectIndex(selectIndex);
        int id = Integer.parseInt(strId);
       
        for(T item : this.listItems){
            if(item.getId() == id){
                objectReturn = item;
            }
        }
        
        return objectReturn;

    }
    
    public String getTypeGeneric(){
        return this.listItems.get(0).getNameClass();
    }

    public JComboBox<String> getCb() {
        return cb;
    }

    public void setCb(JComboBox<String> cb) {
        this.cb = cb;
    }
}
