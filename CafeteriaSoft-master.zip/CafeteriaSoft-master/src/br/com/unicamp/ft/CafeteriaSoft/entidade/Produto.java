/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import br.com.unicamp.ft.CafeteriaSoft.FileData;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author leand
 */
public class Produto extends EntityAbstract implements Serializable{
    
    private int id;
    private String nome;
    private double valor;
    private int quantidade;
    private double custo;
    private Fornecedor fornecedor; 
    //public static String NAME_CLASS = Produto.class.getSimpleName();
    String[] ownAttributes = new String[]{"ID","NOME","VALOR","QUANTIDADE","CUSTO","FORNECEDOR"};
    
    public Produto(){
        
    
    }
    public Produto(String nome, double valor, int quantidade, double custo, Fornecedor fornecedor) {
        super();
        this.nome = nome;
        this.valor = valor;
        this.quantidade = quantidade;
        this.custo = custo;
        this.id = id;
        this.fornecedor = fornecedor;
        
        
    }
    
     public String[] getOwnAtrributes(){
        return this.ownAttributes;
    }
    
    public Fornecedor getFornecedor() {
        return this.fornecedor;
    }
    
    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
    
    public int getId(){
        return this.id;
    }
    
    public void setId (int id){
        this.id = id;
    }

    public double getCusto() {
        return custo;
    }


    public void setCusto(double custo) {
        this.custo = custo;
    }



    public int getQuantidade() {
        return quantidade;
    }

    
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }



    public double getValor() {
        return valor;
    }


    public void setValor(double valor) {
        this.valor = valor;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String ToFormatLineFileTxt(String delimiter) {
        return getId()
               + delimiter
               + getNome()
               + delimiter
               + getFornecedor().id
               + delimiter
               + getQuantidade()
               + delimiter
               + getValor()
               + delimiter
               + getCusto()
               + delimiter;
    }

    @Override
    public void persist() {
       FileData<Produto> fd = new FileData<>(this.getClass().getSimpleName());
       fd.add(this);
    }

    @Override
    public void delete(int id) {
       FileData<Produto> fd = new FileData<>(this.getClass().getSimpleName());
       fd.delete(id);
    }

    @Override
    public Produto get(int id) {
       FileData<Produto> fd = new FileData<>(this.getClass().getSimpleName());
       return fd.get(id);
    }

    @Override
    public String getIdentifier(){
        return getNome();
    }

     @Override
    public Object[] ToObjectArray() {
        Object[] o = new Object[getOwnAtrributes().length];
        
        o[0] = (Object)String.valueOf(getId());
        o[1] = (Object)String.valueOf(getNome());
        o[2] = (Object)String.valueOf(getValor());
        o[3] = (Object)String.valueOf(getQuantidade());
        o[4] = (Object)String.valueOf(getCusto());
        o[4] = (Object)String.valueOf(getFornecedor().getNome());
        
        return o;
    }

}
