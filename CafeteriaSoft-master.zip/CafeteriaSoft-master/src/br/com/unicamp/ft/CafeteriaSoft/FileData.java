/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.unicamp.ft.CafeteriaSoft.entidade.EntityAbstract;
import java.io.FileNotFoundException;
import br.com.unicamp.ft.CafeteriaSoft.Exceptions.NotExistsDataException;
import br.com.unicamp.ft.CafeteriaSoft.entidade.Fornecedor;
import java.io.EOFException;

/**
 *
 * @author leandro
 */
public class FileData<T extends EntityAbstract>{
    
    protected List<T> data;
    protected static String DELIMITER = ";";
    protected static final String DIRECTORY_PATH  = "../CafeteriaSoft-master/files/";
    protected String nameClass;
    protected static String FULL_PATH;
    
    public FileData (String nameClass){
        this.nameClass = nameClass;
        FULL_PATH = DIRECTORY_PATH + this.nameClass;
        this.data = new ArrayList<T>();
        load();
    }    
    
    public void add(T register){
        int id  = getNextId();
        register.setId(id);
        this.data.add(register);
        save();
    }
    
    public void delete(int id){
        try {
            fileIsEmpty();
            
            for(int i = 0; i < this.data.size(); i++){
                T item = this.data.get(i);
                if(item.getId() == id){
                    this.data.remove(i);
                }
            }
            
            save();
        } catch (NotExistsDataException ex) {
            System.out.println("NAO EXISTE DADOS");
        }
    }

    private void save(){
        try {  
            FileOutputStream outFile = new FileOutputStream(FileData.FULL_PATH);
            ObjectOutputStream s = new ObjectOutputStream(outFile);
            s.writeObject(this.data);
            s.close();
        } catch (IOException ex) {
            Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, ex);   
        }
    }
    
    public List load(){
        ObjectInputStream d = null;        
        try {
            FileInputStream inFile = new FileInputStream(FileData.FULL_PATH);
            d = new ObjectInputStream(inFile);
            this.data = (List<T>)d.readObject();
  
            return this.data;            
        } catch (FileNotFoundException e){
            createPath();
            System.out.println("DIRECTORY NOT FOUND AND DIRECTORY CREATED");
            Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, e);
            return load();
        } catch(EOFException e){
            System.out.println("FILE EMPTY");
            Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
            Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                d.close();
            } catch (IOException | NullPointerException ex) {
                System.out.println(ex.getMessage());
                Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }
    
    public T get(int id){
        T registerReturn = null;
        for(T item : this.data){
            if(item.getId() == id){
                registerReturn = item;
            }
        }
        
        return registerReturn;
    }
    
    public List get(){
        return this.data;
    }
    
    public int getNextId(){
        return this.data.size();
    }
    
    private void createPath(){
        File directory = new File(DIRECTORY_PATH);
        File file = new File(FULL_PATH);
         try {
            if(!directory.exists()){
                directory.mkdir();
            }else if(!file.exists()){
                file.createNewFile();   
            }
         } catch (IOException ex) {
             System.out.println(ex.getMessage());
                Logger.getLogger(FileData.class.getName()).log(Level.SEVERE, null, ex);
         }     
    }
    
    public void fileIsEmpty() throws NotExistsDataException{
        if(this.data.isEmpty()){
           throw new NotExistsDataException();
        }
    }
    
    
    public static void main(String[] args){
        FileData<Fornecedor> fs = new FileData<>(new Fornecedor().getNameClass());
        EntityAbstract e = new Fornecedor("n", "n", "n12","n@");
        //e.persist();
        Fornecedor f = fs.get(0);
    }

}
