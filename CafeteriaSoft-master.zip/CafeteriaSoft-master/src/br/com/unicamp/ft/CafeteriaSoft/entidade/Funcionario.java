/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import br.com.unicamp.ft.CafeteriaSoft.FileAbstract;
import br.com.unicamp.ft.CafeteriaSoft.FileData;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.management.StringValueExp;

/**
 *
 * @author leand
 */
public class Funcionario extends Usuario implements Serializable{
    
    private String cpf;
    private double salario;
    public static String NAME_CLASS = Produto.class.getSimpleName();
    String[] ownAttributes = new String[]{"ID","NOME","EMAIL","CPF","SALARIO"};
    
    public Funcionario(){
        
    }
    public Funcionario(String cpf, double salario, String nome, String email) { 
        super(nome, email);        
        this.cpf = cpf;
        this.salario = salario;
    }
    
     public String[] getOwnAtrributes(){
         return this.ownAttributes;
    }

    /**
     *
     * @return
     */
    
    
    @Override
    public String getNome(){
        
        return "Funcionario: " + nome;
    }
    
    public String getEmail(){
        return email;
    }
 
    public double getSalario() {
        return salario;
    }

 
    public void setSalario(double salario) {
        this.salario = salario;
    }

   
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }    

    public String toFormatLineFileTxt(String delimiter) {
        return getId()
               + this.cpf
               + delimiter
               + this.salario;
    }

    @Override
    public void persist() {
       FileData<Funcionario> fd = new FileData<>(this.getClass().getSimpleName());
       fd.add(this);
    }

    @Override
    public void delete(int id) {
       FileData<Funcionario> fd = new FileData<>(this.getClass().getSimpleName());
       fd.delete(this.id);
    }

    @Override
    public EntityAbstract get(int id) {
       FileData<Funcionario> fd = new FileData<>(this.getClass().getSimpleName());
       return fd.get(id);
    }

    @Override
    public Object[] ToObjectArray() {
        Object[] o = new Object[getOwnAtrributes().length];
        
        o[0] = (Object)String.valueOf(getId());
        o[1] = (Object)String.valueOf(getNome());
        o[2] = (Object)String.valueOf(getEmail());
        o[3] = (Object)String.valueOf(getCpf());
        o[4] = (Object)String.valueOf(getSalario());
        
        return o;
    }
}
