/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author leand
 */
public abstract class Usuario extends EntityAbstract implements Serializable{
    
    protected int id;
    protected String nome;
    protected String email;
    protected String[] ownAttributes = new String[]{"ID","NOME","EMAIL"};
    
    public Usuario(){
        
        
    }
    public Usuario(String nome, String email) {
        super();
        this.nome = nome;
        this.email = email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome(){
    return nome;}

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String toFormatLineFileTxt(String delimiter) {
        return this.id 
               + delimiter
               + this.nome
               + delimiter
               + this.email;
    }
    
    @Override
    public String getIdentifier(){
        return getNome();
    }
    
     public String[] getOwnAtrributes(){
         return this.ownAttributes;
    }
}
