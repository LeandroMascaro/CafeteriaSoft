/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import br.com.unicamp.ft.CafeteriaSoft.FileAbstract;
import br.com.unicamp.ft.CafeteriaSoft.FileData;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author leand
 */
public class Fornecedor extends Usuario{
   
    private String cnpj;
    private String telefone;
    String[] ownAttributes = new String[]{"ID","NOME","EMAIL","CNPJ","TELEFONE"};
    
    public Fornecedor(){
    }
    public Fornecedor(String nome, String cnpj, String telefone, String email) {
        super(nome,email);
        this.cnpj = cnpj;
        this.telefone = telefone;
    }
    
    public String[] getOwnAtrributes(){
       return this.ownAttributes;
    }
    
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toFormatLineFileTxt(String delimiter) {
        return getId()
               + delimiter
               + this.cnpj 
               + delimiter
               + this.telefone;
    }
    
    public void parse(String lineTxtWithDelimiter, String delimiter){
        String[] fieldsRegister = lineTxtWithDelimiter.split(delimiter);
        int id = Integer.parseInt(fieldsRegister[0]); 
        String cnpj = fieldsRegister[1];
        String phoneNumber = fieldsRegister[2];
        
        setId(id);
        setNome(nome);
        setTelefone(phoneNumber);
    }

    @Override
    public void persist() {
        FileData<Fornecedor> fd = new FileData<>(this.getClass().getSimpleName());
        fd.add(this);
    }

    @Override
    public void delete(int id) {
        FileData<Fornecedor> fd = new FileData<>(this.getClass().getSimpleName());
        fd.delete(this.id);
    }

    @Override
    public EntityAbstract get(int id) {
       FileData<Fornecedor> fd = new FileData<>(this.getClass().getSimpleName());
       return fd.get(id);       
    }

    @Override
    public Object[] ToObjectArray() {
        Object[] o = new Object[getOwnAtrributes().length];
        
        o[0] = getId();
        o[1] = getNome();
        o[2] = getCnpj();
        o[3] = getTelefone();        
        
        return o;
    }

    /**
     *
     * @return
     */
  
    

}