/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft;

import br.com.unicamp.ft.CafeteriaSoft.entidade.EntityAbstract;
import java.util.List;

/**
 *
 * @author leandro
 */
public abstract class FileAbstract<T extends EntityAbstract> {
    
    // Atrributtes
    protected static String DELIMITER = ";";
    protected static final String PATH  = "../CafeteriaSoft/files/";
            
    // Methods        
    public abstract void add(T register);
    public abstract void save();
    public abstract List load();

    public static String getDELIMITER() {
        return DELIMITER;
    }

    public static void setDELIMITER(String DELIMITER) {
        FileAbstract.DELIMITER = DELIMITER;
    }   
}
