/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author leandro
 */
public abstract class EntityAbstract{
    
   
    //public String toFormatLineFileTxt(String delimiter);
    //public String parse(String lineTxtWithDelimiter);
    
    public static final String[] CHILDREN_CLASS= new String[]{ "Funcionario",
                                                               "Fornecedor",
                                                                "Produto",
                                                                "Venda"};    
    public EntityAbstract(){
    
    }
    
    public abstract String[] getOwnAtrributes();
    public abstract void persist();
    public abstract void delete(int id);
    public abstract EntityAbstract get(int id);
    public abstract int getId();
    public abstract void setId(int id);
    public abstract String getIdentifier();
    public abstract Object[] ToObjectArray(); 
    
    public String getNameClass(){
        return this.getClass().getSimpleName();
    
    }  

    public static Object[][] toMatrixObject(List<EntityAbstract> listItems){
        Object[][] refugiadosMatrix = new Object[listItems.size()][7];
        Object[] refugiadosArray = listItems.toArray();
         
        
        for(int i =  0; i < refugiadosArray.length; i++){
            EntityAbstract entityAbstract = (EntityAbstract)refugiadosArray[i];
            refugiadosMatrix[i]= entityAbstract.ToObjectArray();
        }
        
        return refugiadosMatrix;
    }    
}
