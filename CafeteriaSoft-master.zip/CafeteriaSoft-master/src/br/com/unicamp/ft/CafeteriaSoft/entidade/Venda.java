/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.entidade;

import br.com.unicamp.ft.CafeteriaSoft.FileAbstract;
import br.com.unicamp.ft.CafeteriaSoft.FileData;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author leand
 */
public class Venda  extends EntityAbstract implements Serializable{
    
    private int id;
    private Funcionario funcionario;
    private double valorTotal;
    private String dataVenda;
    private Produto produto;
    private int quantidade;
    //public static String NAME_CLASS = Venda.class.getSimpleName();
    String[] ownAttributes = new String[]{"ID","FUNCIONARIO","VALOR TOTAL","PRODUTO","QUANTIDADE"};
            
    public Venda(){
        
    }
    public Venda(Funcionario funcionario, int quantidade, String dataVenda, Produto produto) {
        super();
        this.funcionario = funcionario;
        this.dataVenda = dataVenda;
        this.produto = produto;
        this.quantidade = quantidade;
        this.valorTotal = this.produto.getValor() * this.quantidade;        
        
    }
    
    public Venda(Funcionario funcionario, int quantidade, Produto produto) {
        super();
        this.funcionario = funcionario;
        this.produto = produto;
        this.quantidade = quantidade;
        this.valorTotal = this.produto.getValor() * this.quantidade;
    }
    
    public String getDataVenda(){
        return dataVenda;
    }
    
    public void setDataVenda(String dataVenda){
        this.dataVenda = dataVenda;
    }
    
    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

  
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    
    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }

    public double getLucro(Produto prod){
        return prod.getValor() - prod.getCusto();
    }
    
    public double getLucro(Produto prod, double desconto){
        return(prod.getValor() - prod.getCusto())*(100 - desconto)/100;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
   
    public String toFormatLineFileTxt(String delimiter) {
        return getId()
               + delimiter
               + getProduto().getId()
               + delimiter
               + getFuncionario().getId()
               + delimiter
               + getDataVenda();                       
    }
    
    

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

   @Override
    public void persist() {
       FileData<Venda> fd = new FileData<>(this.getClass().getSimpleName());
       fd.add(this);
    }

    @Override
    public void delete(int id) {
       FileData<Venda> fd = new FileData<>(this.getClass().getSimpleName());
       fd.delete(id);
    }

    @Override
    public Venda get(int id) {
       FileData<Venda> fd = new FileData<>(this.getClass().getSimpleName());
       return fd.get(id);
    }

    @Override
    public String getIdentifier() {
       return "";
    }

      @Override
    public Object[] ToObjectArray() {
        Object[] o = new Object[getOwnAtrributes().length];
        
        o[0] = (Object)String.valueOf(getId());
        o[1] = (Object)String.valueOf(getFuncionario());
        o[2] = (Object)String.valueOf(getValorTotal());
        o[3] = (Object)String.valueOf(getProduto().getNome());
        o[4] = (Object)String.valueOf(getQuantidade());
        
        return o;
    }
    
    public String[] getOwnAtrributes(){
        return this.ownAttributes;
    }
}
