# CafeteriaSoft

<h2> Objetivos </h2>
Criação de um código bem documentado e funcional para aprendizagem de uma nova linguagem de programação.
<h2> Requisitos </h2>
<ul>
 <li> Cadastro de Funcionários </li>
 <li> Cadastro de Fornecedores </li>
 <li> Cadastro de Produtos </li>
 <li> Consulta de Produtos </li>
 <li> Consulta de Funcionários </li>
 <li> Consulta de Fornecedores </li>
 <li> Excluir Produto </li>
 <li> Excluir Fornecedor </li>
 <li> Cadastrar uma Venda </li>
 <li> Tratamento de Erros </li>
 </ul>
<h2> Componentes de Grupo </h2>
Leandro Mascaro Fernandes             RA: 158101
