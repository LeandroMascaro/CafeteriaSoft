/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.Entidades;

/**
 *
 * @author leand
 */
public class Funcionario {
    
    private String cpf;
    private double salario;
    private String nome;
    private String vendas;

    public Funcionario(String cpf, double salario, String nome, String vendas) {
        this.cpf = cpf;
        this.salario = salario;
        this.nome = nome;
        this.vendas = vendas;
    }

 
    public String getVendas() {
        return vendas;
    }

 
    public void setVendas(String vendas) {
        this.vendas = vendas;
    }

 
    public String getNome() {
        return nome;
    }

 
    public void setNome(String nome) {
        this.nome = nome;
    }

 
    public double getSalario() {
        return salario;
    }

 
    public void setSalario(double salario) {
        this.salario = salario;
    }

   
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

}
