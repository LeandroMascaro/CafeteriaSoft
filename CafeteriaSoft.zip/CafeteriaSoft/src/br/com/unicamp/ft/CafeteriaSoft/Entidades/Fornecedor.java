/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.unicamp.ft.CafeteriaSoft.Entidades;

/**
 *
 * @author leand
 */
public class Fornecedor {
   
    private String nome;
    private String cnpj;
    private String telefone;
    private String email;
    private String produtos;

    public Fornecedor(String nome, String cnpj, String telefone, String email, String produtos) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.telefone = telefone;
        this.email = email;
        this.produtos = produtos;
    }

   
    public String getProdutos() {
        return produtos;
    }


    public void setProdutos(String produtos) {
        this.produtos = produtos;
    }

 
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getTelefone() {
        return telefone;
    }


    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

  
    public String getCnpj() {
        return cnpj;
    }
    
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    }



